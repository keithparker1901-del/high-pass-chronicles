const books = [
  {number:1,title:'The Pass That Collects',subtitle:'An Old-World Dark Fantasy of Winter Roads and Dark Mercy',asin:'B0GQ6VBHKC',slug:'the-pass-that-collects',cover:'assets/covers/01-pass-that-collects.jpg',tags:['road'],themes:'winter roads · dark mercy · names as payment'},
  {number:2,title:'The Road That Remembers',subtitle:'An Old-World Dark Fantasy of Haunted Roads and Buried Oaths',asin:'B0GGXK18BR',slug:'the-road-that-remembers',cover:'assets/covers/02-road-that-remembers.jpg',tags:['road'],themes:'haunted routes · pursuit · buried oaths'},
  {number:3,title:'The Stone That Keeps Count',subtitle:'An Old-World Gothic Fantasy of Oaths and Salt',asin:'B0GRPRCP17',slug:'the-stone-that-keeps-count',cover:'assets/covers/03-stone-that-keeps-count.jpg',tags:['road','mercy'],themes:'stone · salt · oaths · physical proof'},
  {number:4,title:'The Court Above the Hinge',subtitle:'An Old-World Gothic Fantasy of Judgment and Fire',asin:'B0GS75HZY5',slug:'the-court-above-the-hinge',cover:'assets/covers/04-court-above-hinge.jpg',tags:['house','mercy'],themes:'judgment · fire · thresholds · burden'},
  {number:5,title:'The Moon That Hunts',subtitle:'An Old-World Dark Fantasy of Blood, Moonlight, and the Hound-King',asin:'B0GSSH5XNG',slug:'the-moon-that-hunts',cover:'assets/covers/05-moon-that-hunts.jpg',tags:['road'],themes:'folk horror · moonlight · hound · winter watch'},
  {number:6,title:'The Cry That Found the Stones',subtitle:'An Old-World Gothic Fantasy of Mourning and Mountain Roads',asin:'B0GTN76D5Y',slug:'the-cry-that-found-the-stones',cover:'assets/covers/06-cry-found-stones.jpg',tags:['road','mercy'],themes:'mourning · denied names · stone memory'},
  {number:7,title:'The House That Kept the Last Lamp',subtitle:'An Old-World Gothic Fantasy of Deathwatch and False Mercy',asin:'B0GR6J5JJ6',slug:'the-house-that-kept-the-last-lamp',cover:'assets/covers/07-house-last-lamp.jpg',tags:['house','mercy'],themes:'deathwatch · lamp · community · false mercy'},
  {number:8,title:'The Lady Beneath Midnight',subtitle:'An Old-World Gothic Fantasy of Beauty, Dominion, and False Inheritance',asin:'B0GQ55GPLL',slug:'the-lady-beneath-midnight',cover:'assets/covers/08-lady-beneath-midnight.jpg',tags:['house','mercy'],themes:'beauty · dominion · inheritance · bodily claim'},
  {number:10,title:'The House That Would Not Release',subtitle:'An Old-World Gothic Fantasy of Wrongful Keeping and Hard-Won Passage',asin:'B0GX33F82R',slug:'the-house-that-would-not-release',cover:'assets/covers/10-house-not-release.jpg',tags:['house','mercy'],themes:'custody · doors · ledgers · wrongful keeping'},
  {number:14,title:'The Ministry of the Second Dawn',subtitle:'An Old-World Gothic Fantasy of False Mercy, Red Lamps, and Names Returned',asin:'B0GX5488VK',slug:'the-ministry-of-the-second-dawn',cover:'assets/covers/14-ministry-second-dawn.jpg',tags:['mercy'],themes:'red lamps · administration · dependency · names returned'},
  {number:15,title:'The Door of Ninety-Five Nails',subtitle:'An Old-World Gothic Fantasy of Reform, Unheard War, and Sacred Defiance',asin:'B0GZJYJJ1N',slug:'the-door-of-ninety-five-nails',cover:'assets/covers/15-door-ninety-five-nails.jpg',tags:['house'],themes:'door · nails · sacred defiance · consequence'},
  {number:16,title:'The Twisted Sister',subtitle:'The High Pass Chronicles Book Sixteen',asin:'B0GZQMFYBS',slug:'the-twisted-sister',cover:'assets/covers/16-twisted-sister.jpg',tags:['mercy','house'],themes:'poisoned wedding · vows · mirrors · possession'},
  {number:17,title:'The Mask That Fed the Rats',subtitle:'An Old-World Gothic Fantasy of Mercy, Hunger, and Erased Names',asin:'B0H34NLK39',slug:'the-mask-that-fed-the-rats',cover:'assets/covers/17-mask-fed-rats.jpg',tags:['mercy'],themes:'mask · rats · hunger · erased names'}
];

const grid=document.querySelector('#book-grid');
const search=document.querySelector('#book-search');
const buttons=[...document.querySelectorAll('.filter-button')];
const noResults=document.querySelector('#no-results');
const dialog=document.querySelector('#book-dialog');
const dialogContent=document.querySelector('#dialog-content');
let activeFilter='all';
const esc=s=>s.replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));

function card(book){return `<article class="book-card reveal visible" data-tags="${book.tags.join(' ')}">
  <button class="cover-button" type="button" data-book="${book.number}" aria-label="View details for ${esc(book.title)}"><img class="real-cover" src="${book.cover}" alt="Cover of ${esc(book.title)}, Book ${book.number} of The High Pass Chronicles" loading="lazy"></button>
  <div class="book-meta"><div class="book-order">Book ${book.number}</div><h3>${esc(book.title)}</h3><p>${esc(book.themes)}</p>
  <div class="book-actions"><a href="books/${book.slug}.html">Book page</a><a href="https://www.amazon.com/dp/${book.asin}" target="_blank" rel="noopener">Buy on Amazon</a></div></div></article>`}
function render(){const q=search.value.trim().toLowerCase();const visible=books.filter(b=>(activeFilter==='all'||b.tags.includes(activeFilter))&&`${b.number} ${b.title} ${b.subtitle} ${b.themes}`.toLowerCase().includes(q));grid.innerHTML=visible.map(card).join('');noResults.hidden=visible.length>0;}
function show(number){const b=books.find(x=>x.number===Number(number));if(!b)return;dialogContent.innerHTML=`<div class="dialog-layout"><div class="dialog-cover-image"><img src="${b.cover}" alt="Cover of ${esc(b.title)}"></div><div class="dialog-copy"><p class="section-kicker">The High Pass Chronicles · Book ${b.number}</p><h2 id="dialog-title">${esc(b.title)}</h2><p class="dialog-subtitle">${esc(b.subtitle)}</p><div class="dialog-details"><span><strong>Official series number:</strong> Book ${b.number}</span><span><strong>Amazon ASIN:</strong> ${b.asin}</span><span><strong>Core themes:</strong> ${esc(b.themes)}</span></div><a class="button primary" href="https://www.amazon.com/dp/${b.asin}" target="_blank" rel="noopener">Buy on Amazon</a></div></div>`;dialog.showModal();}
grid.addEventListener('click',e=>{const el=e.target.closest('[data-book]');if(el)show(el.dataset.book)});
search.addEventListener('input',render);
buttons.forEach(b=>b.addEventListener('click',()=>{activeFilter=b.dataset.filter;buttons.forEach(x=>x.classList.toggle('active',x===b));render()}));
document.querySelector('.dialog-close').addEventListener('click',()=>dialog.close());
dialog.addEventListener('click',e=>{const r=dialog.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)dialog.close()});
const menu=document.querySelector('.menu-toggle'),nav=document.querySelector('.site-nav');menu.addEventListener('click',()=>{const open=nav.classList.toggle('open');menu.setAttribute('aria-expanded',String(open))});nav.addEventListener('click',e=>{if(e.target.tagName==='A'){nav.classList.remove('open');menu.setAttribute('aria-expanded','false')}});
window.addEventListener('scroll',()=>document.querySelector('.site-header').classList.toggle('scrolled',scrollY>20),{passive:true});
const observer=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting){e.target.classList.add('visible');observer.unobserve(e.target)}}),{threshold:.08});document.querySelectorAll('.reveal').forEach(e=>observer.observe(e));
document.querySelector('#year').textContent=new Date().getFullYear();
render();
const schema = {
  '@context': 'https://schema.org',
  '@type': 'CollectionPage',
  name: 'The High Pass Chronicles',
  author: {'@type':'Person', name:'R. Keith Parker'},
  mainEntity: {
    '@type': 'ItemList',
    itemListElement: books.map((b, i) => ({
      '@type': 'ListItem',
      position: i + 1,
      item: {
        '@type': 'Book',
        name: b.title,
        bookEdition: `Book ${b.number}`,
        author: {'@type':'Person', name:'R. Keith Parker'},
        url: `https://www.amazon.com/dp/${b.asin}`,
        image: b.cover,
        identifier: {'@type':'PropertyValue', propertyID:'ASIN', value:b.asin}
      }
    }))
  }
};
document.querySelector('#book-schema').textContent = JSON.stringify(schema);
