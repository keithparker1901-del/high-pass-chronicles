# The High Pass Chronicles — Flagship Website

This is a complete static website that works without GitHub, Netlify, WordPress, or a website builder.

## Open it
Double-click `index.html`. All pages, cover images, author photography, styles, and scripts are contained inside this folder.

## Update it
- Main homepage: `index.html`
- Visual design: `styles.css`
- Book catalog data and interactions: `script.js`
- Individual book pages: `books/`
- World lore: `world.html`
- Author page: `author.html`
- Reading guide: `reading-guide.html`
- Images: `assets/`

## Public publishing
A public web address always requires a host. The site itself does not depend on any particular host and can be uploaded to any static web host or ordinary web server.
